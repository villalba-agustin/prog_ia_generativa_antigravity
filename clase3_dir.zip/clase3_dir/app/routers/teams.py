import os
import uuid
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, status
from sqlalchemy.orm import Session
from typing import List
from app.database import get_db
from app.models import Team, Match, TournamentState
from app.schemas import TeamCreate, TeamUpdate, TeamResponse
from app.routers.auth import require_admin

router = APIRouter(prefix="/api/teams", tags=["Equipos"])

UPLOAD_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "static", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

@router.get("", response_model=List[TeamResponse])
def get_teams(db: Session = Depends(get_db)):
    return db.query(Team).order_by(Team.name.asc()).all()

@router.post("/upload-shield", dependencies=[Depends(require_admin)])
async def upload_shield(file: UploadFile = File(...)):
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="El archivo subido debe ser una imagen (PNG, JPG, SVG, WEBP, etc.).")

    ext = os.path.splitext(file.filename)[1]
    if not ext:
        ext = ".png"

    filename = f"shield_{uuid.uuid4().hex[:10]}{ext}"
    filepath = os.path.join(UPLOAD_DIR, filename)

    content = await file.read()
    with open(filepath, "wb") as f:
        f.write(content)

    return {"url": f"/static/uploads/{filename}"}

@router.post("", response_model=TeamResponse, status_code=status.HTTP_201_CREATED, dependencies=[Depends(require_admin)])
def create_team(team_in: TeamCreate, db: Session = Depends(get_db)):
    state = db.query(TournamentState).first()
    if state and state.is_generated:
        raise HTTPException(
            status_code=400,
            detail="No se pueden agregar equipos una vez que el torneo ya ha sido generado."
        )

    # Verificar duplicados por nombre
    existing = db.query(Team).filter(Team.name.ilike(team_in.name.strip())).first()
    if existing:
        raise HTTPException(
            status_code=400,
            detail=f"Ya existe un equipo registrado con el nombre '{team_in.name}'."
        )

    new_team = Team(
        name=team_in.name.strip(),
        shield_url=team_in.shield_url.strip() if team_in.shield_url else None
    )
    db.add(new_team)
    db.commit()
    db.refresh(new_team)
    return new_team

@router.put("/{team_id}", response_model=TeamResponse, dependencies=[Depends(require_admin)])
def update_team(team_id: int, team_in: TeamUpdate, db: Session = Depends(get_db)):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Equipo no encontrado.")

    if team_in.name and team_in.name.strip() != team.name:
        existing = db.query(Team).filter(Team.name.ilike(team_in.name.strip()), Team.id != team_id).first()
        if existing:
            raise HTTPException(status_code=400, detail=f"Ya existe otro equipo con el nombre '{team_in.name}'.")
        team.name = team_in.name.strip()

    if team_in.shield_url is not None:
        team.shield_url = team_in.shield_url.strip() if team_in.shield_url else None

    db.commit()
    db.refresh(team)
    return team

@router.delete("/{team_id}", status_code=status.HTTP_204_NO_CONTENT, dependencies=[Depends(require_admin)])
def delete_team(team_id: int, db: Session = Depends(get_db)):
    team = db.query(Team).filter(Team.id == team_id).first()
    if not team:
        raise HTTPException(status_code=404, detail="Equipo no encontrado.")

    state = db.query(TournamentState).first()
    if state and state.is_generated:
        # Al eliminar un equipo con el torneo en curso, se reinicia el fixture para mantener la consistencia
        state.is_generated = False
        state.total_rounds = 0
        db.query(Match).delete()

    db.delete(team)
    db.commit()
    return None
